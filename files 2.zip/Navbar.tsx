"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { motion, useScroll, useMotionValueEvent, AnimatePresence } from "framer-motion";
import { ShoppingBag, Search, User } from "lucide-react";
import { MobileMenu } from "./MobileMenu";

const navLinks = [
  { label: "Collections", href: "/collections" },
  { label: "Murals",      href: "/murals" },
  { label: "Textures",    href: "/textures" },
  { label: "Lookbook",    href: "/lookbook" },
  { label: "About",       href: "/about" },
];

export function Navbar() {
  const [scrolled,     setScrolled]     = useState(false);
  const [mobileOpen,   setMobileOpen]   = useState(false);
  const [activeLink,   setActiveLink]   = useState<string | null>(null);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    setScrolled(latest > 20);
  });

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  return (
    <>
      {/* Grain texture bar — the signature element */}
      <motion.div
        className="fixed top-0 left-0 right-0 z-50 h-[3px]"
        style={{
          background: "linear-gradient(90deg, #C8A96E 0%, #DFC99A 30%, #C8A96E 60%, #9A7040 100%)",
          backgroundSize: "200% 100%",
        }}
        animate={{ backgroundPosition: ["0% 0%", "100% 0%", "0% 0%"] }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
      />

      <motion.header
        className="fixed top-[3px] left-0 right-0 z-40 transition-all duration-300"
        animate={{
          backgroundColor: scrolled ? "rgba(245, 240, 232, 0.96)" : "rgba(245, 240, 232, 0)",
          backdropFilter: scrolled ? "blur(12px)" : "blur(0px)",
          borderBottomColor: scrolled ? "rgba(232, 224, 212, 1)" : "rgba(232, 224, 212, 0)",
        }}
        style={{ borderBottomWidth: 1, borderBottomStyle: "solid" }}
        transition={{ duration: 0.3, ease: "easeOut" }}
      >
        <nav
          className="mx-auto flex items-center justify-between px-6 md:px-10 lg:px-16"
          style={{ height: "var(--nav-height)" }}
          aria-label="Main navigation"
        >
          {/* Logo */}
          <Link href="/" className="group flex flex-col leading-none select-none" aria-label="Wonder Wallz home">
            <motion.span
              className="font-display text-xl font-semibold tracking-tight"
              style={{ color: "var(--color-midnight)", letterSpacing: "-0.03em" }}
              whileHover={{ color: "var(--color-gold)" }}
              transition={{ duration: 0.2 }}
            >
              Wonder
            </motion.span>
            <motion.span
              className="font-display text-[10px] font-normal tracking-[0.3em] uppercase"
              style={{ color: "var(--color-ash)", marginTop: "-2px" }}
            >
              Wallz
            </motion.span>
          </Link>

          {/* Desktop Nav Links */}
          <ul className="hidden lg:flex items-center gap-8" role="list">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="relative font-body text-sm font-medium py-1"
                  style={{ color: "var(--color-walnut)" }}
                  onMouseEnter={() => setActiveLink(link.href)}
                  onMouseLeave={() => setActiveLink(null)}
                >
                  <span className="relative z-10 transition-colors duration-200 hover:text-[var(--color-midnight)]">
                    {link.label}
                  </span>
                  <AnimatePresence>
                    {activeLink === link.href && (
                      <motion.span
                        className="absolute bottom-0 left-0 right-0 h-[1.5px] rounded-full"
                        style={{ backgroundColor: "var(--color-gold)" }}
                        initial={{ scaleX: 0, originX: 0 }}
                        animate={{ scaleX: 1 }}
                        exit={{ scaleX: 0, originX: 1 }}
                        transition={{ duration: 0.25, ease: "easeOut" }}
                      />
                    )}
                  </AnimatePresence>
                </Link>
              </li>
            ))}
          </ul>

          {/* Action Icons */}
          <div className="flex items-center gap-3">
            <NavIconButton aria-label="Search">
              <Search size={18} />
            </NavIconButton>

            <NavIconButton aria-label="Account" className="hidden md:flex">
              <User size={18} />
            </NavIconButton>

            <NavIconButton aria-label="Cart (0 items)" className="relative">
              <ShoppingBag size={18} />
              <motion.span
                className="absolute -top-1 -right-1 flex items-center justify-center w-4 h-4 rounded-full text-[10px] font-semibold font-body"
                style={{ backgroundColor: "var(--color-gold)", color: "var(--color-midnight)" }}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 15 }}
              >
                0
              </motion.span>
            </NavIconButton>

            {/* Hamburger — mobile only */}
            <button
              className="lg:hidden flex flex-col justify-center items-center w-9 h-9 gap-[5px] rounded-md focus-visible:outline-offset-2"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation menu"
              aria-expanded={mobileOpen}
            >
              {[0, 1, 2].map((i) => (
                <motion.span
                  key={i}
                  className="block h-[1.5px] rounded-full"
                  style={{
                    backgroundColor: "var(--color-walnut)",
                    width: i === 1 ? "18px" : "22px",
                  }}
                />
              ))}
            </button>
          </div>
        </nav>
      </motion.header>

      {/* Spacer so content starts below fixed nav */}
      <div style={{ height: "calc(var(--nav-height) + 3px)" }} />

      <MobileMenu
        isOpen={mobileOpen}
        onClose={() => setMobileOpen(false)}
        links={navLinks}
      />
    </>
  );
}

/* ── Shared icon button ───────────────────────────────── */
function NavIconButton({
  children,
  className = "",
  "aria-label": ariaLabel,
}: {
  children: React.ReactNode;
  className?: string;
  "aria-label": string;
}) {
  return (
    <motion.button
      aria-label={ariaLabel}
      className={`relative flex items-center justify-center w-9 h-9 rounded-full transition-colors ${className}`}
      style={{ color: "var(--color-walnut)" }}
      whileHover={{
        backgroundColor: "var(--color-linen)",
        color: "var(--color-midnight)",
      }}
      whileTap={{ scale: 0.92 }}
      transition={{ duration: 0.15 }}
    >
      {children}
    </motion.button>
  );
}
