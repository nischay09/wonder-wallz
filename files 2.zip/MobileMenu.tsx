"use client";

import { useRef } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { X, ArrowRight } from "lucide-react";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  links: { label: string; href: string }[];
}

const secondaryLinks = [
  { label: "FAQs",              href: "/faqs" },
  { label: "Shipping & Returns", href: "/shipping" },
  { label: "Trade Program",     href: "/trade" },
  { label: "Contact Us",        href: "/contact" },
];

const curtain = {
  hidden:  { clipPath: "inset(0 0 100% 0)", opacity: 1 },
  visible: {
    clipPath: "inset(0 0 0% 0)",
    opacity: 1,
    transition: { duration: 0.55, ease: [0.76, 0, 0.24, 1] },
  },
  exit: {
    clipPath: "inset(0 0 100% 0)",
    opacity: 1,
    transition: { duration: 0.45, ease: [0.76, 0, 0.24, 1], delay: 0.1 },
  },
};

const linkItem = {
  hidden:  { opacity: 0, x: -24 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: { delay: 0.3 + i * 0.07, duration: 0.4, ease: "easeOut" },
  }),
  exit: { opacity: 0, x: -16, transition: { duration: 0.2 } },
};

const overlay = {
  hidden:  { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.35 } },
  exit:    { opacity: 0, transition: { duration: 0.35, delay: 0.15 } },
};

export function MobileMenu({ isOpen, onClose, links }: MobileMenuProps) {
  const closeRef = useRef<HTMLButtonElement>(null);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            key="mobile-overlay"
            className="fixed inset-0 z-50"
            style={{ backgroundColor: "rgba(13, 13, 13, 0.45)" }}
            variants={overlay}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={onClose}
            aria-hidden="true"
          />

          {/* Drawer */}
          <motion.div
            key="mobile-drawer"
            role="dialog"
            aria-modal="true"
            aria-label="Navigation menu"
            className="fixed top-0 right-0 bottom-0 z-50 flex flex-col w-full max-w-sm"
            style={{ backgroundColor: "var(--color-midnight)" }}
            variants={curtain}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            {/* Grain accent strip */}
            <div
              className="absolute top-0 left-0 right-0 h-[3px]"
              style={{
                background:
                  "linear-gradient(90deg, #C8A96E 0%, #DFC99A 40%, #C8A96E 100%)",
              }}
            />

            {/* Header row */}
            <div className="flex items-center justify-between px-8 pt-7 pb-6">
              <Link
                href="/"
                onClick={onClose}
                className="flex flex-col leading-none"
                aria-label="Wonder Wallz home"
              >
                <span
                  className="font-display text-lg font-semibold"
                  style={{ color: "var(--color-parchment)", letterSpacing: "-0.03em" }}
                >
                  Wonder
                </span>
                <span
                  className="font-body text-[9px] font-normal tracking-[0.35em] uppercase"
                  style={{ color: "var(--color-gold)", marginTop: "-1px" }}
                >
                  Wallz
                </span>
              </Link>

              <motion.button
                ref={closeRef}
                onClick={onClose}
                aria-label="Close navigation menu"
                className="flex items-center justify-center w-9 h-9 rounded-full"
                style={{ color: "var(--color-ash)", border: "1px solid rgba(154,145,137,0.3)" }}
                whileHover={{
                  backgroundColor: "rgba(200,169,110,0.15)",
                  color: "var(--color-gold)",
                  borderColor: "rgba(200,169,110,0.5)",
                }}
                whileTap={{ scale: 0.9 }}
                transition={{ duration: 0.15 }}
              >
                <X size={16} />
              </motion.button>
            </div>

            {/* Divider */}
            <div
              className="mx-8 mb-8"
              style={{ height: "1px", backgroundColor: "rgba(232,224,212,0.1)" }}
            />

            {/* Primary nav links */}
            <nav className="flex-1 px-8 overflow-y-auto" aria-label="Mobile navigation">
              <ul role="list" className="space-y-1">
                {links.map((link, i) => (
                  <motion.li
                    key={link.href}
                    custom={i}
                    variants={linkItem}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                  >
                    <Link
                      href={link.href}
                      onClick={onClose}
                      className="group flex items-center justify-between py-3.5 border-b"
                      style={{ borderColor: "rgba(232,224,212,0.08)" }}
                    >
                      <span
                        className="font-display text-2xl font-medium transition-colors duration-200 group-hover:text-[var(--color-gold)]"
                        style={{ color: "var(--color-parchment)" }}
                      >
                        {link.label}
                      </span>
                      <motion.span
                        style={{ color: "var(--color-ash)" }}
                        className="group-hover:text-[var(--color-gold)] transition-colors duration-200"
                        initial={{ x: 0, opacity: 0.4 }}
                        whileHover={{ x: 4, opacity: 1 }}
                      >
                        <ArrowRight size={16} />
                      </motion.span>
                    </Link>
                  </motion.li>
                ))}
              </ul>

              {/* Secondary links */}
              <motion.div
                className="mt-10"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1, transition: { delay: 0.65, duration: 0.4 } }}
                exit={{ opacity: 0 }}
              >
                <p
                  className="font-body text-[10px] font-semibold uppercase tracking-[0.2em] mb-4"
                  style={{ color: "var(--color-ash)" }}
                >
                  Help & Info
                </p>
                <ul role="list" className="space-y-3">
                  {secondaryLinks.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        onClick={onClose}
                        className="font-body text-sm transition-colors duration-200 hover:text-[var(--color-gold)]"
                        style={{ color: "rgba(232,224,212,0.55)" }}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </motion.div>
            </nav>

            {/* Bottom CTA */}
            <motion.div
              className="px-8 py-8"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0, transition: { delay: 0.6, duration: 0.4 } }}
              exit={{ opacity: 0 }}
            >
              <Link
                href="/collections"
                onClick={onClose}
                className="flex items-center justify-center gap-2 w-full py-3.5 rounded-full font-body text-sm font-semibold transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
                style={{
                  backgroundColor: "var(--color-gold)",
                  color: "var(--color-midnight)",
                }}
              >
                Browse Collections
                <ArrowRight size={15} />
              </Link>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
