"use client";

import Link from "next/link";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Instagram, Pinterest, ArrowRight } from "lucide-react";

const footerColumns = [
  {
    heading: "Shop",
    links: [
      { label: "All Collections", href: "/collections" },
      { label: "Murals",          href: "/murals" },
      { label: "Textures",        href: "/textures" },
      { label: "New Arrivals",    href: "/new" },
      { label: "Sale",            href: "/sale" },
    ],
  },
  {
    heading: "Discover",
    links: [
      { label: "Lookbook",        href: "/lookbook" },
      { label: "The Journal",     href: "/journal" },
      { label: "Trade Program",   href: "/trade" },
      { label: "About Wonder Wallz", href: "/about" },
    ],
  },
  {
    heading: "Support",
    links: [
      { label: "Shipping & Returns", href: "/shipping" },
      { label: "Installation Guide", href: "/installation" },
      { label: "FAQs",               href: "/faqs" },
      { label: "Contact Us",         href: "/contact" },
    ],
  },
];

const socialLinks = [
  { label: "Instagram", href: "https://instagram.com", Icon: Instagram },
  { label: "Pinterest",  href: "https://pinterest.com", Icon: Pinterest },
];

const fadeUp = {
  hidden:  { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.55, ease: "easeOut" },
  }),
};

export function Footer() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <footer
      ref={ref}
      className="relative overflow-hidden"
      style={{ backgroundColor: "var(--color-midnight)" }}
      aria-labelledby="footer-heading"
    >
      <h2 id="footer-heading" className="sr-only">Footer navigation</h2>

      {/* Top section */}
      <div className="mx-auto max-w-7xl px-6 md:px-10 lg:px-16 pt-16 md:pt-24 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">

          {/* Brand column */}
          <motion.div
            className="lg:col-span-2"
            custom={0}
            variants={fadeUp}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
          >
            <Link href="/" className="inline-flex flex-col leading-none mb-6" aria-label="Wonder Wallz home">
              <span
                className="font-display text-2xl font-semibold"
                style={{ color: "var(--color-parchment)", letterSpacing: "-0.03em" }}
              >
                Wonder
              </span>
              <span
                className="font-body text-[10px] tracking-[0.35em] uppercase"
                style={{ color: "var(--color-gold)", marginTop: "-2px" }}
              >
                Wallz
              </span>
            </Link>

            <p
              className="font-body text-sm leading-relaxed max-w-xs mb-8"
              style={{ color: "rgba(232,224,212,0.55)" }}
            >
              Statement wallpapers for spaces that refuse to be ordinary. Every roll tells a story.
            </p>

            {/* Newsletter */}
            <p
              className="font-body text-xs font-semibold uppercase tracking-[0.15em] mb-3"
              style={{ color: "var(--color-ash)" }}
            >
              Get the Journal
            </p>
            <div className="flex items-center gap-0 max-w-xs">
              <input
                type="email"
                placeholder="your@email.com"
                aria-label="Email for newsletter"
                className="flex-1 px-4 py-2.5 text-sm font-body bg-transparent border rounded-l-full outline-none transition-colors duration-200 focus:border-[var(--color-gold)]"
                style={{
                  borderColor: "rgba(154,145,137,0.35)",
                  color: "var(--color-parchment)",
                }}
              />
              <motion.button
                aria-label="Subscribe to newsletter"
                className="flex items-center justify-center w-10 h-10 rounded-r-full shrink-0"
                style={{ backgroundColor: "var(--color-gold)", color: "var(--color-midnight)" }}
                whileHover={{ backgroundColor: "var(--color-gold-light)" }}
                whileTap={{ scale: 0.94 }}
                transition={{ duration: 0.15 }}
              >
                <ArrowRight size={15} />
              </motion.button>
            </div>
          </motion.div>

          {/* Nav columns */}
          {footerColumns.map((col, colIndex) => (
            <motion.div
              key={col.heading}
              custom={colIndex + 1}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
            >
              <p
                className="font-body text-[10px] font-semibold uppercase tracking-[0.2em] mb-5"
                style={{ color: "var(--color-ash)" }}
              >
                {col.heading}
              </p>
              <ul role="list" className="space-y-3">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="font-body text-sm transition-colors duration-200 hover:text-[var(--color-gold)]"
                      style={{ color: "rgba(232,224,212,0.6)" }}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Gold divider */}
      <div
        className="mx-6 md:mx-10 lg:mx-16"
        style={{ height: "1px", backgroundColor: "rgba(200,169,110,0.2)" }}
      />

      {/* Bottom bar */}
      <motion.div
        className="mx-auto max-w-7xl px-6 md:px-10 lg:px-16 py-6 flex flex-col md:flex-row items-center justify-between gap-4"
        custom={4}
        variants={fadeUp}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
      >
        <p
          className="font-body text-xs"
          style={{ color: "rgba(154,145,137,0.7)" }}
        >
          © {new Date().getFullYear()} Wonder Wallz. All rights reserved.
        </p>

        <div className="flex items-center gap-6">
          {/* Legal links */}
          <div className="flex gap-5">
            {["Privacy Policy", "Terms of Use", "Cookie Settings"].map((label) => (
              <Link
                key={label}
                href={`/${label.toLowerCase().replace(/\s+/g, "-")}`}
                className="font-body text-xs transition-colors duration-200 hover:text-[var(--color-parchment)]"
                style={{ color: "rgba(154,145,137,0.6)" }}
              >
                {label}
              </Link>
            ))}
          </div>

          {/* Social icons */}
          <div className="flex items-center gap-3" aria-label="Social media links">
            {socialLinks.map(({ label, href, Icon }) => (
              <motion.a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="flex items-center justify-center w-8 h-8 rounded-full transition-colors duration-200"
                style={{
                  color: "var(--color-ash)",
                  border: "1px solid rgba(154,145,137,0.3)",
                }}
                whileHover={{
                  color: "var(--color-gold)",
                  borderColor: "rgba(200,169,110,0.5)",
                  backgroundColor: "rgba(200,169,110,0.1)",
                }}
                whileTap={{ scale: 0.9 }}
              >
                <Icon size={13} />
              </motion.a>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Background watermark */}
      <div
        className="pointer-events-none select-none absolute bottom-0 right-0 font-display font-semibold leading-none overflow-hidden"
        style={{
          fontSize: "clamp(6rem, 18vw, 14rem)",
          color: "rgba(200,169,110,0.04)",
          transform: "translate(10%, 20%)",
          letterSpacing: "-0.04em",
        }}
        aria-hidden="true"
      >
        WW
      </div>
    </footer>
  );
}
